﻿Public Class Form2
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If RadioButton1.Checked = True Then
            If MaskedTextBox1.Text <> "" Then
                If ComboBox1.SelectedIndex = 0 Then '秒
                    Form1.Timer2.Interval = MaskedTextBox1.Text * 1000
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                ElseIf ComboBox1.SelectedIndex = 1 Then '分
                    Form1.Timer2.Interval = MaskedTextBox1.Text * 1000 * 60
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                ElseIf ComboBox1.SelectedIndex = 2 Then '时
                    Form1.Timer2.Interval = MaskedTextBox1.Text * 1000 * 60 * 60
                    Form1.Timer2.Enabled = True
                    Form1.Hide()
                    Me.Close()
                End If
            Else
                MsgBox("隐藏时间不能为空！", MsgBoxStyle.Critical, "错误")
            End If
        ElseIf RadioButton2.Checked = True Then
            End
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
        ComboBox1.SelectedText = "秒"
    End Sub
End Class