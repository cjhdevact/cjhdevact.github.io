# TimeControl - 时钟小工具


转到[发布页](https://github.com/cjhdevact/TimeControl/releases)下载程序或源代码。
早期版本的源代码也在发布页里。

------------

程序截图：


主程序界面


![主程序界面（125%缩放）](Assets/MainUI.png)


设置界面


![设置界面（125%缩放）](Assets/SettingUI.png)


------------


本程序基于 `GPL-3.0` 授权。